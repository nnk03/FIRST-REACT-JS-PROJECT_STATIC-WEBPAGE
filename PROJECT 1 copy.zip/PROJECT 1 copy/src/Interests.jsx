import React from "react";
import ReactDOM from "react-dom/client";
import "./App.css";

export default function Interests() {
  return (
    <>
      <div className="interests">
        <h3>Interests</h3>
        <p>
          Lorem ipsum, dolor sit amet consectetur adipisicing elit. Placeat
          eaque ut ab voluptatum dicta doloremque repellendus dolore optio
          natus, animi officia deserunt? Tenetur veniam voluptate porro officiis
          autem doloremque adipisci.
        </p>
      </div>
    </>
  );
}

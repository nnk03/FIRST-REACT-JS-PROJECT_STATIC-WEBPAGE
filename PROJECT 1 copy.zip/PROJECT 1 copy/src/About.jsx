import React from "react";
import ReactDOM from "react-dom/client";
import "./App.css";

export default function About() {
  return (
    <>
      <div className="about">
        <h3>About</h3>
        <p>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Explicabo
          quos in aliquid quam aperiam minus rem dolores vero fugit, impedit
          consequatur dicta, perspiciatis non! Corporis minima hic dolores
          repudiandae labore.
        </p>
      </div>
    </>
  );
}

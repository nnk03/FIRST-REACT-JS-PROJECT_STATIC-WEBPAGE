import React from "react";
import ReactDOM from "react-dom/client";
import "./App.css";

export default function Photo() {
  return <div className="photo"></div>;
}
